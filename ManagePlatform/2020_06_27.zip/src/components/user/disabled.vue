<template>
	<div>
		<div class="toolbar">
			<p class="title">禁用列表</p>
		</div>
		<div class="content">
			<el-table :data="users" border stripe size="mini">
				<el-table-column prop="no" label="工号" width="100" />
				<el-table-column prop="name" label="姓名" align="center" width="130" />
				<el-table-column prop="email" label="邮箱" align="center" />
				<el-table-column prop="phone" label="电话" align="center" width="120" />
				<el-table-column prop="ext" label="分机" align="center" width="100" />
				<el-table-column label="恢复" width="60px" align="center" fixed="right">
					<template slot-scope="scope">
						<el-button
							size="mini"
							type="warning"
							icon="el-icon-plus"
							circle
							@click="recoverClick(scope.row)"
						/>
					</template>
				</el-table-column>
				<el-table-column label="删除" width="60px" align="center" fixed="right">
					<template slot-scope="scope">
						<el-button
							size="mini"
							type="danger"
							icon="el-icon-delete"
							circle
							@click="deleteClick(scope.row)"
						/>
					</template>
				</el-table-column>
			</el-table>
			<el-pagination
				style="margin-top: 16px"
				@size-change="queryUsers"
				@current-change="queryUsers"
				:current-page.sync="current_page"
				:page-sizes="[10, 20, 30, 50]"
				:page-size="page_size"
				layout="total, prev, pager, next"
				:hide-on-single-page="false"
				:total="total"
			/>
		</div>
	</div>
</template>
<script>
	import { queryUsers, disableUser, deleteUser } from '../../api/iot.js'
	export default {
		data() {
			return {
				users: [],
				current_page: 1,
				page_size: 10,
				total: 0
			}
		},
		mounted() {
			this.queryUsers()
		},
		methods: {
			recoverClick: function (val) {
				this.$confirm(`此操作将恢复 ' ${val.id} ${val.name} ' 的使用，是否继续？`, '提示', {
					confirmButtonText: '恢复',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					disableUser(val.id, 0).then(res => {
						if (res.status == 200) {
							this.$message({
								message: '启用成功',
								type: 'success',
								showClose: true
							})
							this.queryUsers()
						} else {
							this.$message({
								message: '启用失败',
								type: 'error',
								showClose: true
							})
						}
					})
				})
			},
			deleteClick: function (val) {
				this.$confirm(`此操作将彻底删除 ' ${val.no} ${val.name} ' ，是否继续？`, '提示', {
					confirmButtonText: '删除',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					deleteUser(val.id).then(res => {
						if (res.status == 200) {
							this.$message({
								message: '删除成功',
								type: 'success',
								showClose: true
							})
							this.queryUsers()
						} else {
							this.$message({
								message: '删除失败',
								type: 'error',
								showClose: true
							})
						}
					})
				})
			},
			queryUsers() {
				queryUsers('', 1, this.current_page - 1, this.page_size).then(res => {
					if (res.status == 200) {
						if (res.data.data != null) {
							this.users = res.data.data.content
							this.total = res.data.data.totalElements
						} else {
							this.users = []
							this.total = 0
						}						
					}
				})
			}
		}
	}
</script>